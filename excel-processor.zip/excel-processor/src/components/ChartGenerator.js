// filepath: c:\Users\alima\Projects\excel-processor\src\components\ChartGenerator.js
import React from 'react';
import { Bar, Line, Pie } from 'react-chartjs-2'; // Example charting library

const ChartGenerator = ({ data }) => {
  const chartData = {
    labels: data.labels,
    datasets: [
      {
        label: 'Dataset 1',
        data: data.values,
        backgroundColor: 'rgba(75,192,192,0.4)',
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 1,
      },
    ],
  };

  return (
    <div>
      <h2>Chart Generator</h2>
      <Bar data={chartData} />
      <Line data={chartData} />
      <Pie data={chartData} />
    </div>
  );
};

export default ChartGenerator;