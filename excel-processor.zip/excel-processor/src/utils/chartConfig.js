const chartConfig = {
  bar: {
    type: 'bar',
    options: {
      responsive: true,
      scales: {
        x: {
          beginAtZero: true,
        },
      },
    },
  },
  line: {
    type: 'line',
    options: {
      responsive: true,
      scales: {
        x: {
          beginAtZero: true,
        },
      },
    },
  },
  pie: {
    type: 'pie',
    options: {
      responsive: true,
    },
  },
  // Add more chart types and configurations as needed
};

export default chartConfig;