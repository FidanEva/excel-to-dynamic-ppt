# README.md

# Excel Processor

This project is a web application designed to process data from multiple Excel files with specific templates. It allows users to upload Excel files, generate various types of charts based on the aggregated data, and export these charts as a PDF file.

## Features

- **Dashboard**: Main entry point displaying an overview and navigation to other functionalities.
- **Upload Files**: Functionality to upload Excel files and parse their contents.
- **Chart Generation**: Create various types of charts based on the aggregated data from the uploaded Excel files.
- **PDF Export**: Export generated charts as a PDF file.
- **Settings**: Configure application settings, such as chart preferences and export options.
- **404 Not Found**: User-friendly error page for non-existent routes.

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd excel-processor
   ```
3. Install dependencies:
   ```
   npm install
   ```

## Usage

To start the application, run:
```
npm start
```
This will launch the app in your default web browser.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License.